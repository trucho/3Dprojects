                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:290700
iPhone Amplifier Stand by 3DBROOKLYN is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is a passive amp for an iphone (fits most with cases) that holds your iphone up on its side, with the buttons facing up.

See more at:<br>
<b>Instagram:</b> <a href="https://www.instagram.com/3dbrooklyn/?hl=en">@3DBrooklyn</a>
<b>Facebook:</b><a href="www.facebook.com/3DBROOKLYN"> 3DBrooklyn</a>

<div itemscope itemtype="http://schema.org/LocalBusiness">
<a itemprop="url" href="http://www.3dbrooklyn.com"><div itemprop="name"><strong>3D Brooklyn</strong></div>
</a>
<div itemprop="description">3D Modeling, Laser Cutting and 3D Printing Service in Brooklyn New York. We design useful products from 100% compostable & 100% recyclable plastics. </div><br>
<div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
<strong>Address : </strong><br><span itemprop="streetAddress">385 Troutman Street, Studio 303</span>,<br>
<span itemprop="addressLocality">Brooklyn</span>,<br>
<span itemprop="addressRegion">New York</span> - 
<span itemprop="postalCode">11237</span><br>
<span itemprop="addressCountry">United States</span>.<br>
</div><br>
<strong>Tel : </strong><span itemprop="telephone"><a href="tel:347-688-5203">347-688-5203</a></span><br>
                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:773759
Mechanical Iris by sketchpunk is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

**V2 : Small improvements go a long way**
Finally had time to finish modeling this project. Surprised at the amount of makes and I feel bad for you guys printing something that was incomplete. To make life easier, I updated 3 parts and added a new part to make the iris, but if you already printed the leafs, you can reuse them with the new parts. Hopefully this will give you guys a better table top piece to show off 3d printing.

**ORIGINAL POST V1**
Saw a diy paper mechanical iris thing online and thought it was pretty cool. I couldn't find this style of iris on thingiverse, so I research different designs and found one that might be 3D printable on instructables.  

The trickiest part was getting the leafs printed thin enough plus have a pin on both sides. After a few leaf attempts I got it working fairly well, sadly It can not close all the way. Can't make the thing work any thinner then 0.6mm, maybe a different leaf design will allow it to close and probably use less leafs.  

This was really made as a 3D Printing Proof of concept. At some point down the line I might try to refine it by making some steam punk goggles, Also thinking of a possible camera lens cap that slides open and close when I need it without removing the cap.  

Inspired from Instructables Article :  
http://www.instructables.com/id/How-to-make-a-12-leaves-Mechanical-Irirs/


___
####Support SketchPunk Labs
Patreon - https://www.patreon.com/sketchpunk
Amazon Shop - http://astore.amazon.com/sketclabs-20

# Instructions

Need to print 11 leaf and pins. Glue the pins to the leafs so that there is a pin facing outward on each side. From there just use some clamp thing to help keep things together as you lay the leafs on the base.